package week_01;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class frm_Playfair extends JFrame {

    private JTextArea txt_plaintext;
    private JTextField txt_key;
    private JTextArea txt_matrix;
    private JButton btn_matrix;
    private JTextArea txt_ciphertext;
    private JButton btn_encrypt;
    private JButton btn_decrypt;
    private JButton btn_open;
    private JButton btn_save;
    private JLabel lbl_status;

    public frm_Playfair() {
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        setTitle("Playfair Cipher");
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JLabel lbl_title = new JLabel("MẬT MÃ PLAYFAIR", SwingConstants.CENTER);
        lbl_title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lbl_title.setAlignmentX(0.5f);
        mainPanel.add(lbl_title);
        mainPanel.add(Box.createVerticalStrut(10));

        JLabel lbl_pt = new JLabel("Plaintext:");
        lbl_pt.setAlignmentX(0.0f);
        mainPanel.add(lbl_pt);
        mainPanel.add(Box.createVerticalStrut(4));

        txt_plaintext = new JTextArea(3, 40);
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setWrapStyleWord(true);
        JScrollPane sp_plaintext = new JScrollPane(txt_plaintext);
        sp_plaintext.setAlignmentX(0.0f);
        mainPanel.add(sp_plaintext);
        mainPanel.add(Box.createVerticalStrut(10));

        JPanel keyPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        keyPanel.setAlignmentX(0.0f);
        JLabel lbl_key = new JLabel("Key:");
        txt_key = new JTextField("KEYWORD", 12);
        JLabel lbl_key_hint = new JLabel("Chỉ gồm chữ A-Z, ví dụ KEYWORD");
        keyPanel.add(lbl_key);
        keyPanel.add(txt_key);
        keyPanel.add(lbl_key_hint);
        mainPanel.add(keyPanel);
        mainPanel.add(Box.createVerticalStrut(10));

        JPanel matrixPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        matrixPanel.setAlignmentX(0.0f);
        JLabel lbl_matrix = new JLabel("Key Matrix:");
        txt_matrix = new JTextArea(5, 9);
        txt_matrix.setEditable(false);
        txt_matrix.setFont(new Font("Monospaced", Font.BOLD, 14));
        JScrollPane sp_matrix = new JScrollPane(txt_matrix);
        sp_matrix.setPreferredSize(new Dimension(170, 112));
        btn_matrix = new JButton("Generate Key Matrix");
        matrixPanel.add(lbl_matrix);
        matrixPanel.add(sp_matrix);
        matrixPanel.add(btn_matrix);
        mainPanel.add(matrixPanel);
        mainPanel.add(Box.createVerticalStrut(10));

        JLabel lbl_ct = new JLabel("Ciphertext:");
        lbl_ct.setAlignmentX(0.0f);
        mainPanel.add(lbl_ct);
        mainPanel.add(Box.createVerticalStrut(4));

        txt_ciphertext = new JTextArea(3, 40);
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setWrapStyleWord(true);
        JScrollPane sp_ciphertext = new JScrollPane(txt_ciphertext);
        sp_ciphertext.setAlignmentX(0.0f);
        mainPanel.add(sp_ciphertext);
        mainPanel.add(Box.createVerticalStrut(12));

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        btnPanel.setAlignmentX(0.0f);
        btn_encrypt = new JButton("Encrypt");
        btn_decrypt = new JButton("Decrypt");
        btn_open = new JButton("Open Ciphertext File");
        btn_save = new JButton("Save Ciphertext File");
        btnPanel.add(btn_encrypt);
        btnPanel.add(btn_decrypt);
        btnPanel.add(btn_open);
        btnPanel.add(btn_save);
        mainPanel.add(btnPanel);
        mainPanel.add(Box.createVerticalStrut(12));

        lbl_status = new JLabel("Sẵn sàng.");
        lbl_status.setAlignmentX(0.0f);
        mainPanel.add(lbl_status);

        btn_matrix.addActionListener(evt -> btn_matrixActionPerformed(evt));
        btn_encrypt.addActionListener(evt -> btn_encryptActionPerformed(evt));
        btn_decrypt.addActionListener(evt -> btn_decryptActionPerformed(evt));
        btn_open.addActionListener(evt -> btn_openActionPerformed(evt));
        btn_save.addActionListener(evt -> btn_saveActionPerformed(evt));

        setContentPane(mainPanel);
        pack();
        setMinimumSize(new Dimension(620, 520));
    }

    private void btn_matrixActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            txt_matrix.setText(PlayfairCipher.getKeyMatrix(txt_key.getText()));
            txt_matrix.setCaretPosition(0);
            lbl_status.setText("Đã tạo ma trận khóa 5x5 (I và J dùng chung ô).");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Khóa không hợp lệ", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btn_encryptActionPerformed(java.awt.event.ActionEvent evt) {
        String plaintext = txt_plaintext.getText();
        if (plaintext.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Hãy nhập Plaintext trước khi mã hóa.");
            return;
        }
        try {
            String key = txt_key.getText().trim();
            txt_ciphertext.setText(PlayfairCipher.encrypt(plaintext, key));
            lbl_status.setText("Đã mã hóa Playfair (bỏ dấu cách, J -> I, chèn X).");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Dữ liệu không hợp lệ", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btn_decryptActionPerformed(java.awt.event.ActionEvent evt) {
        String ciphertext = txt_ciphertext.getText();
        if (ciphertext.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Hãy nhập Ciphertext trước khi giải mã.");
            return;
        }
        try {
            String key = txt_key.getText().trim();
            txt_plaintext.setText(PlayfairCipher.decrypt(ciphertext, key));
            lbl_status.setText("Đã giải mã Playfair (còn ký tự đệm X).");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Dữ liệu không hợp lệ", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btn_openActionPerformed(java.awt.event.ActionEvent evt) {
        String path = FileTextIO.openText(this, txt_ciphertext);
        if (path != null) {
            lbl_status.setText("Đã mở tệp: " + path);
        }
    }

    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {
        String path = FileTextIO.saveText(this, txt_ciphertext, "playfair_ciphertext.txt");
        if (path != null) {
            lbl_status.setText("Đã lưu tệp: " + path);
        }
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new frm_Playfair().setVisible(true));
    }
}

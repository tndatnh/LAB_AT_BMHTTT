package week_01;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class frm_TanCong extends JFrame {

    private JTextArea txt_cipher;
    private JButton btn_bruteforce;
    private JButton btn_frequency;
    private JTextField txt_known_plain;
    private JTextField txt_known_cipher;
    private JButton btn_known;
    private JTextArea txt_result;
    private JLabel lbl_status;

    public frm_TanCong() {
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        setTitle("Phân tích mật mã cổ điển");
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JLabel lbl_title = new JLabel("PHÂN TÍCH (TẤN CÔNG) MẬT MÃ CỔ ĐIỂN", SwingConstants.CENTER);
        lbl_title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lbl_title.setAlignmentX(0.5f);
        mainPanel.add(lbl_title);
        mainPanel.add(Box.createVerticalStrut(10));

        JLabel lbl_c = new JLabel("Ciphertext:");
        lbl_c.setAlignmentX(0.0f);
        mainPanel.add(lbl_c);
        mainPanel.add(Box.createVerticalStrut(4));

        txt_cipher = new JTextArea(2, 40);
        txt_cipher.setLineWrap(true);
        txt_cipher.setWrapStyleWord(true);
        JScrollPane sp_cipher = new JScrollPane(txt_cipher);
        sp_cipher.setAlignmentX(0.0f);
        mainPanel.add(sp_cipher);
        mainPanel.add(Box.createVerticalStrut(8));

        JPanel pnl_caesar = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        pnl_caesar.setAlignmentX(0.0f);
        btn_bruteforce = new JButton("Brute Force Caesar");
        btn_frequency = new JButton("Frequency Analysis");
        pnl_caesar.add(btn_bruteforce);
        pnl_caesar.add(btn_frequency);
        mainPanel.add(pnl_caesar);
        mainPanel.add(Box.createVerticalStrut(10));

        JPanel pnl_known = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        pnl_known.setAlignmentX(0.0f);
        JLabel lbl_kp = new JLabel("Bản rõ đã biết:");
        txt_known_plain = new JTextField("HELLO", 8);
        JLabel lbl_kc = new JLabel("Bản mã:");
        txt_known_cipher = new JTextField("RIJVS", 8);
        btn_known = new JButton("Known Plaintext (Vigenere)");
        pnl_known.add(lbl_kp);
        pnl_known.add(txt_known_plain);
        pnl_known.add(lbl_kc);
        pnl_known.add(txt_known_cipher);
        pnl_known.add(btn_known);
        mainPanel.add(pnl_known);
        mainPanel.add(Box.createVerticalStrut(10));

        JLabel lbl_res = new JLabel("Kết quả:");
        lbl_res.setAlignmentX(0.0f);
        mainPanel.add(lbl_res);
        mainPanel.add(Box.createVerticalStrut(4));

        txt_result = new JTextArea(12, 40);
        txt_result.setEditable(false);
        txt_result.setFont(new Font("Monospaced", Font.PLAIN, 13));
        JScrollPane sp_result = new JScrollPane(txt_result);
        sp_result.setAlignmentX(0.0f);
        mainPanel.add(sp_result);
        mainPanel.add(Box.createVerticalStrut(10));

        lbl_status = new JLabel("Sẵn sàng.");
        lbl_status.setAlignmentX(0.0f);
        mainPanel.add(lbl_status);

        btn_bruteforce.addActionListener(evt -> btn_bruteforceActionPerformed(evt));
        btn_frequency.addActionListener(evt -> btn_frequencyActionPerformed(evt));
        btn_known.addActionListener(evt -> btn_knownActionPerformed(evt));

        setContentPane(mainPanel);
        pack();
        setMinimumSize(new Dimension(640, 520));
    }

    private void btn_bruteforceActionPerformed(java.awt.event.ActionEvent evt) {
        String cipher = txt_cipher.getText().trim();
        if (cipher.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Hãy nhập Ciphertext.");
            return;
        }
        txt_result.setText(AttackDemos.caesarBruteForce(cipher));
        txt_result.setCaretPosition(0);
        lbl_status.setText("Đã thử đủ 26 khóa Caesar.");
    }

    private void btn_frequencyActionPerformed(java.awt.event.ActionEvent evt) {
        String cipher = txt_cipher.getText().trim();
        if (cipher.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Hãy nhập Ciphertext.");
            return;
        }
        txt_result.setText(AttackDemos.frequency(cipher));
        txt_result.setCaretPosition(0);
        lbl_status.setText("Đã thống kê tần suất chữ cái.");
    }

    private void btn_knownActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            String key = AttackDemos.knownPlaintext(txt_known_plain.getText(), txt_known_cipher.getText());
            txt_result.setText("Khóa Vigenère suy ra từng vị trí: " + key
                    + "\nNếu khóa ngắn hơn bản rõ, khóa sẽ lặp lại (KEY KEY ...).");
            lbl_status.setText("Khóa suy ra: " + key);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Dữ liệu không hợp lệ", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new frm_TanCong().setVisible(true));
    }
}

package week_01;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class frm_Menu extends JFrame {

    private JButton btn_caesar;
    private JButton btn_vigenere;
    private JButton btn_railfence;
    private JButton btn_playfair;
    private JButton btn_transposition;
    private JButton btn_autokey;
    private JButton btn_tonghop;
    private JButton btn_tancong;
    private JButton btn_sql;

    public frm_Menu() {
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        setTitle("LAB 1 - Mã hóa đối xứng cổ điển");
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));

        JLabel lbl_title = new JLabel("LAB 1 - MÃ HÓA ĐỐI XỨNG CỔ ĐIỂN", SwingConstants.CENTER);
        lbl_title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lbl_title.setAlignmentX(0.5f);
        mainPanel.add(lbl_title);
        mainPanel.add(Box.createVerticalStrut(10));

        JLabel lbl_sub = new JLabel("Chọn một bài để mở form tương ứng:", SwingConstants.CENTER);
        lbl_sub.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lbl_sub.setAlignmentX(0.5f);
        mainPanel.add(lbl_sub);
        mainPanel.add(Box.createVerticalStrut(20));

        JPanel gridPanel = new JPanel(new GridLayout(3, 3, 15, 15));
        gridPanel.setAlignmentX(0.5f);

        btn_caesar = new JButton("1.1 Caesar");
        btn_vigenere = new JButton("1.2 Vigenère");
        btn_railfence = new JButton("1.3 Rail Fence");
        btn_playfair = new JButton("1.4 Playfair");
        btn_transposition = new JButton("1.5 Transposition");
        btn_autokey = new JButton("1.6 Autokey");
        btn_tonghop = new JButton("Nâng cao 01 - Tổng hợp");
        btn_tancong = new JButton("Nâng cao 02 - Tấn công");
        btn_sql = new JButton("Kết nối SQL Server");

        Dimension btnSize = new Dimension(200, 36);
        for (JButton b : new JButton[]{btn_caesar, btn_vigenere, btn_railfence,
            btn_playfair, btn_transposition, btn_autokey, btn_tonghop, btn_tancong, btn_sql}) {
            b.setPreferredSize(btnSize);
            b.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        }

        gridPanel.add(btn_caesar);
        gridPanel.add(btn_vigenere);
        gridPanel.add(btn_railfence);
        gridPanel.add(btn_playfair);
        gridPanel.add(btn_transposition);
        gridPanel.add(btn_autokey);
        gridPanel.add(btn_tonghop);
        gridPanel.add(btn_tancong);
        gridPanel.add(btn_sql);

        mainPanel.add(gridPanel);
        mainPanel.add(Box.createVerticalStrut(20));

        JLabel lbl_note = new JLabel("Mỗi form mở ra là một cửa sổ riêng; đóng form con không làm tắt chương trình.", SwingConstants.CENTER);
        lbl_note.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        lbl_note.setAlignmentX(0.5f);
        mainPanel.add(lbl_note);

        btn_caesar.addActionListener(evt -> new frm_Caesar().setVisible(true));
        btn_vigenere.addActionListener(evt -> new frm_Vigenere().setVisible(true));
        btn_railfence.addActionListener(evt -> new frm_RailFence().setVisible(true));
        btn_playfair.addActionListener(evt -> new frm_Playfair().setVisible(true));
        btn_transposition.addActionListener(evt -> new frm_Transposition().setVisible(true));
        btn_autokey.addActionListener(evt -> new frm_Autokey().setVisible(true));
        btn_tonghop.addActionListener(evt -> new frm_TongHop().setVisible(true));
        btn_tancong.addActionListener(evt -> new frm_TanCong().setVisible(true));
        btn_sql.addActionListener(evt -> new frm_KetNoiSQL().setVisible(true));

        setContentPane(mainPanel);
        pack();
        setMinimumSize(new Dimension(680, 320));
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new frm_Menu().setVisible(true));
    }
}

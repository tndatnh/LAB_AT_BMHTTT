package week_01;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class frm_TongHop extends JFrame {

    private JComboBox<String> cbo_algorithm;
    private JLabel lbl_hint;
    private JTextArea txt_plaintext;
    private JTextField txt_key;
    private JTextArea txt_ciphertext;
    private JButton btn_encrypt;
    private JButton btn_decrypt;
    private JButton btn_open;
    private JButton btn_save;
    private JButton btn_sql;
    private JButton btn_history;
    private JLabel lbl_status;

    public frm_TongHop() {
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        setTitle("Chương trình tổng hợp - 6 thuật toán");
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JLabel lbl_title = new JLabel("CHƯƠNG TRÌNH TỔNG HỢP 6 THUẬT TOÁN CỔ ĐIỂN", SwingConstants.CENTER);
        lbl_title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lbl_title.setAlignmentX(0.5f);
        mainPanel.add(lbl_title);
        mainPanel.add(Box.createVerticalStrut(10));

        JPanel algoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        algoPanel.setAlignmentX(0.0f);
        JLabel lbl_algo = new JLabel("Thuật toán:");
        cbo_algorithm = new JComboBox<>(CipherTongHop.ALGORITHMS);
        lbl_hint = new JLabel("Khóa mẫu: 3");
        algoPanel.add(lbl_algo);
        algoPanel.add(cbo_algorithm);
        algoPanel.add(Box.createHorizontalStrut(10));
        algoPanel.add(lbl_hint);
        mainPanel.add(algoPanel);
        mainPanel.add(Box.createVerticalStrut(10));

        JLabel lbl_pt = new JLabel("Plaintext:");
        lbl_pt.setAlignmentX(0.0f);
        mainPanel.add(lbl_pt);
        mainPanel.add(Box.createVerticalStrut(4));

        txt_plaintext = new JTextArea(3, 40);
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setWrapStyleWord(true);
        JScrollPane sp_plaintext = new JScrollPane(txt_plaintext);
        sp_plaintext.setAlignmentX(0.0f);
        mainPanel.add(sp_plaintext);
        mainPanel.add(Box.createVerticalStrut(10));

        JPanel keyPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        keyPanel.setAlignmentX(0.0f);
        JLabel lbl_key = new JLabel("Key:");
        txt_key = new JTextField("3", 15);
        keyPanel.add(lbl_key);
        keyPanel.add(txt_key);
        mainPanel.add(keyPanel);
        mainPanel.add(Box.createVerticalStrut(10));

        JLabel lbl_ct = new JLabel("Ciphertext:");
        lbl_ct.setAlignmentX(0.0f);
        mainPanel.add(lbl_ct);
        mainPanel.add(Box.createVerticalStrut(4));

        txt_ciphertext = new JTextArea(3, 40);
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setWrapStyleWord(true);
        JScrollPane sp_ciphertext = new JScrollPane(txt_ciphertext);
        sp_ciphertext.setAlignmentX(0.0f);
        mainPanel.add(sp_ciphertext);
        mainPanel.add(Box.createVerticalStrut(12));

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 0));
        btnPanel.setAlignmentX(0.0f);
        btn_encrypt = new JButton("Encrypt");
        btn_decrypt = new JButton("Decrypt");
        btn_open = new JButton("Open File");
        btn_save = new JButton("Save File");
        btn_sql = new JButton("Kết nối SQL Server");
        btn_history = new JButton("Xem lịch sử");
        btnPanel.add(btn_encrypt);
        btnPanel.add(btn_decrypt);
        btnPanel.add(btn_open);
        btnPanel.add(btn_save);
        btnPanel.add(btn_sql);
        btnPanel.add(btn_history);
        mainPanel.add(btnPanel);
        mainPanel.add(Box.createVerticalStrut(12));

        lbl_status = new JLabel("Sẵn sàng.");
        lbl_status.setAlignmentX(0.0f);
        mainPanel.add(lbl_status);

        cbo_algorithm.addActionListener(evt -> cbo_algorithmActionPerformed(evt));
        btn_encrypt.addActionListener(evt -> btn_encryptActionPerformed(evt));
        btn_decrypt.addActionListener(evt -> btn_decryptActionPerformed(evt));
        btn_open.addActionListener(evt -> btn_openActionPerformed(evt));
        btn_save.addActionListener(evt -> btn_saveActionPerformed(evt));
        btn_sql.addActionListener(evt -> btn_sqlActionPerformed(evt));
        btn_history.addActionListener(evt -> btn_historyActionPerformed(evt));

        setContentPane(mainPanel);
        pack();
        setMinimumSize(new Dimension(680, 420));
    }

    private void cbo_algorithmActionPerformed(java.awt.event.ActionEvent evt) {
        String algorithm = (String) cbo_algorithm.getSelectedItem();
        txt_key.setText(CipherTongHop.sampleKey(algorithm));
        lbl_hint.setText("Khóa mẫu: " + CipherTongHop.sampleKey(algorithm));
    }

    private void btn_encryptActionPerformed(java.awt.event.ActionEvent evt) {
        String algorithm = (String) cbo_algorithm.getSelectedItem();
        String input = txt_plaintext.getText();
        try {
            String result = CipherTongHop.encrypt(algorithm, input, txt_key.getText());
            txt_ciphertext.setText(result);
            String saved = HistoryDao.tryInsert(algorithm, "ENCRYPT", input, result);
            lbl_status.setText("Đã mã hóa " + algorithm + ". " + saved);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Dữ liệu không hợp lệ", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btn_decryptActionPerformed(java.awt.event.ActionEvent evt) {
        String algorithm = (String) cbo_algorithm.getSelectedItem();
        String input = txt_ciphertext.getText();
        try {
            String result = CipherTongHop.decrypt(algorithm, input, txt_key.getText());
            txt_plaintext.setText(result);
            String saved = HistoryDao.tryInsert(algorithm, "DECRYPT", input, result);
            lbl_status.setText("Đã giải mã " + algorithm + ". " + saved);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Dữ liệu không hợp lệ", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btn_openActionPerformed(java.awt.event.ActionEvent evt) {
        String path = FileTextIO.openText(this, txt_ciphertext);
        if (path != null) {
            lbl_status.setText("Đã mở tệp: " + path);
        }
    }

    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {
        String path = FileTextIO.saveText(this, txt_ciphertext, "ciphertext.txt");
        if (path != null) {
            lbl_status.setText("Đã lưu tệp: " + path);
        }
    }

    private void btn_sqlActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_KetNoiSQL().setVisible(true);
    }

    private void btn_historyActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_LichSu().setVisible(true);
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new frm_TongHop().setVisible(true));
    }
}

package week_01;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class frm_KetNoiSQL extends JFrame {

    private JTextField txt_server;
    private JTextField txt_port;
    private JTextField txt_database;
    private JTextField txt_user;
    private JPasswordField txt_password;
    private JButton btn_test;
    private JButton btn_history;
    private JLabel lbl_status;

    public frm_KetNoiSQL() {
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        setTitle("Kết nối Microsoft SQL Server");
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 25, 15, 25));

        JLabel lbl_title = new JLabel("KẾT NỐI MICROSOFT SQL SERVER", SwingConstants.CENTER);
        lbl_title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lbl_title.setAlignmentX(0.5f);
        mainPanel.add(lbl_title);
        mainPanel.add(Box.createVerticalStrut(15));

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setAlignmentX(0.5f);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Server:"), gbc);
        gbc.gridx = 1;
        txt_server = new JTextField("127.0.0.1", 20);
        formPanel.add(txt_server, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(new JLabel("Port:"), gbc);
        gbc.gridx = 1;
        txt_port = new JTextField("14333", 10);
        formPanel.add(txt_port, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(new JLabel("Database:"), gbc);
        gbc.gridx = 1;
        txt_database = new JTextField("LAB1_MaHoaCoDien", 20);
        formPanel.add(txt_database, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        formPanel.add(new JLabel("User:"), gbc);
        gbc.gridx = 1;
        txt_user = new JTextField("lab1_user", 20);
        formPanel.add(txt_user, gbc);

        gbc.gridx = 0; gbc.gridy = 4;
        formPanel.add(new JLabel("Password:"), gbc);
        gbc.gridx = 1;
        txt_password = new JPasswordField(20);
        formPanel.add(txt_password, gbc);

        mainPanel.add(formPanel);
        mainPanel.add(Box.createVerticalStrut(15));

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        btnPanel.setAlignmentX(0.5f);
        btn_test = new JButton("Test Connection");
        btn_history = new JButton("Xem lịch sử");
        btnPanel.add(btn_test);
        btnPanel.add(btn_history);
        mainPanel.add(btnPanel);
        mainPanel.add(Box.createVerticalStrut(15));

        lbl_status = new JLabel("Chưa kết nối.", SwingConstants.CENTER);
        lbl_status.setAlignmentX(0.5f);
        mainPanel.add(lbl_status);

        btn_test.addActionListener(evt -> btn_testActionPerformed(evt));
        btn_history.addActionListener(evt -> btn_historyActionPerformed(evt));

        setContentPane(mainPanel);
        pack();
        setMinimumSize(new Dimension(500, 360));
    }

    private void btn_testActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            int port = Integer.parseInt(txt_port.getText().trim());
            DbConfig.set(txt_server.getText().trim(), port, txt_database.getText().trim(),
                    txt_user.getText().trim(), txt_password.getPassword());
            lbl_status.setText("<html>" + DbConfig.test() + "</html>");
        } catch (Exception ex) {
            DbConfig.clear();
            lbl_status.setText("<html>Kết nối thất bại: " + ex.getMessage() + "</html>");
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Không kết nối được SQL Server", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btn_historyActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_LichSu().setVisible(true);
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new frm_KetNoiSQL().setVisible(true));
    }
}

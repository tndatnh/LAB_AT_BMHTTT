package week_01;

public class CipherTest {

    public static void main(String[] args) {
        int passed = 0;
        int total = 0;

        // 1. Caesar
        total++;
        String c_c = CaesarCipher.encrypt("HELLO", 3);
        String c_d = CaesarCipher.decrypt(c_c, 3);
        if ("KHOOR".equals(c_c) && "HELLO".equals(c_d)) {
            System.out.println("[PASS] Caesar: HELLO -> " + c_c + " -> " + c_d);
            passed++;
        } else {
            System.err.println("[FAIL] Caesar expected KHOOR, got " + c_c);
        }

        // 2. Vigenere
        total++;
        String v_c = VigenereCipher.encrypt("HELLO", "KEY");
        String v_d = VigenereCipher.decrypt(v_c, "KEY");
        if ("RIJVS".equals(v_c) && "HELLO".equals(v_d)) {
            System.out.println("[PASS] Vigenere: HELLO -> " + v_c + " -> " + v_d);
            passed++;
        } else {
            System.err.println("[FAIL] Vigenere expected RIJVS, got " + v_c);
        }

        // 3. Rail Fence
        total++;
        String r_c = RailFenceCipher.encrypt("HELLO WORLD", 3);
        String r_d = RailFenceCipher.decrypt(r_c, 3);
        if ("HOREL OLLWD".equals(r_c) && "HELLO WORLD".equals(r_d)) {
            System.out.println("[PASS] Rail Fence: HELLO WORLD -> " + r_c + " -> " + r_d);
            passed++;
        } else {
            System.err.println("[FAIL] Rail Fence expected 'HOREL OLLWD', got '" + r_c + "'");
        }

        // 4. Playfair
        total++;
        String p_c = PlayfairCipher.encrypt("HELLOWORLD", "KEYWORD");
        String p_d = PlayfairCipher.decrypt(p_c, "KEYWORD");
        if ("GYIZSCOKCFBU".equals(p_c) && "HELXLOWORLDX".equals(p_d)) {
            System.out.println("[PASS] Playfair: HELLOWORLD -> " + p_c + " -> " + p_d);
            passed++;
        } else {
            System.err.println("[FAIL] Playfair expected GYIZSCOKCFBU, got " + p_c + ", decrypted: " + p_d);
        }

        // 5. Transposition
        total++;
        int[] transKey = TranspositionCipher.parseKey("2,3,1");
        String t_c = TranspositionCipher.encrypt("BAOMAT", transKey);
        String t_d = TranspositionCipher.decrypt(t_c, transKey);
        if ("AAOTBM".equals(t_c) && "BAOMAT".equals(t_d)) {
            System.out.println("[PASS] Transposition: BAOMAT -> " + t_c + " -> " + t_d);
            passed++;
        } else {
            System.err.println("[FAIL] Transposition expected AAOTBM, got " + t_c);
        }

        // 6. Autokey
        total++;
        String a_c = AutokeyCipher.encrypt("HELLO", "KEY");
        String a_d = AutokeyCipher.decrypt(a_c, "KEY");
        if ("RIJSS".equals(a_c) && "HELLO".equals(a_d)) {
            System.out.println("[PASS] Autokey: HELLO -> " + a_c + " -> " + a_d);
            passed++;
        } else {
            System.err.println("[FAIL] Autokey expected RIJSS, got " + a_c);
        }

        // 7. CipherTongHop
        total++;
        boolean thOk = true;
        for (String alg : CipherTongHop.ALGORITHMS) {
            String sk = CipherTongHop.sampleKey(alg);
            String enc = CipherTongHop.encrypt(alg, "TEST", sk);
            String dec = CipherTongHop.decrypt(alg, enc, sk);
            if (!dec.toUpperCase().startsWith("TEST")) {
                thOk = false;
                System.err.println("[FAIL] TongHop algorithm " + alg + " failed.");
            }
        }
        if (thOk) {
            System.out.println("[PASS] CipherTongHop: All 6 algorithms round-trip successfully.");
            passed++;
        }

        // 8. AttackDemos
        total++;
        String bf = AttackDemos.caesarBruteForce("KHOOR");
        String freq = AttackDemos.frequency("PHHW PH DIWHU WKH WRJD SDUWB");
        String kp = AttackDemos.knownPlaintext("HELLO", "RIJVS");
        if (bf.contains("khóa k = 3, bản rõ = HELLO") && freq.contains("Tổng số chữ: 23") && "KEYKE".equals(kp)) {
            System.out.println("[PASS] AttackDemos: Brute force, Frequency, Known plaintext all correct.");
            passed++;
        } else {
            System.err.println("[FAIL] AttackDemos failed.");
        }

        System.out.println("========================================");
        System.out.println("Passed " + passed + " / " + total + " test suites successfully!");
        if (passed != total) {
            System.exit(1);
        }
    }
}
